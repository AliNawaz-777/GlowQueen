 <?php

 return [
    'name'    => 'Webkul Bagisto Checkout',
    'version' => '0.0.1'
 ];
