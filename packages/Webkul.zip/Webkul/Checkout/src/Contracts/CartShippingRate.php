<?php

namespace Webkul\Checkout\Contracts;

interface CartShippingRate
{
}