 <?php

 return [
    'name'    => 'Webkul Bagisto Categories',
    'version' => '0.0.1'
 ];
