<?php

namespace Webkul\Customer\Contracts;

interface Wishlist
{
}