<?php

return [
    'slug' => ':attribute باید نامک معتبر داشته باشد.',
    'code' => ':attribute باید معتبر باشد.',
    'decimal' => ':attribute باید معتبر باشد.'
];
