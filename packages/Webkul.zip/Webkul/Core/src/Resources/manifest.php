<?php

 return [
    'name'    => 'Webkul Bagisto Core',
    'version' => '0.0.1'
 ];
