<?php

namespace Webkul\Core\Contracts;

interface Channel
{
}