<?php

namespace Webkul\Core\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ChannelProxy extends ModelProxy
{

}