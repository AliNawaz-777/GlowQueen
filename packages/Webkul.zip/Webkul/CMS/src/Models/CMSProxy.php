<?php

namespace Webkul\CMS\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CMSProxy extends ModelProxy
{

}