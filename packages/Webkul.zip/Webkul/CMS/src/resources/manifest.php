<?php

 return [
    'name'    => 'Webkul Bagisto Cms',
    'version' => '0.0.1'
 ];
