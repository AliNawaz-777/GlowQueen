<?php

namespace Webkul\Category\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CategoryTranslationProxy extends ModelProxy
{

}