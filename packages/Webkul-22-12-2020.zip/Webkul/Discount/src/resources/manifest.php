<?php

 return [
    'name'    => 'Webkul Bagisto Discount',
    'version' => '0.0.1'
 ];
