<?php

namespace Webkul\Discount\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartRuleCouponsProxy extends ModelProxy
{

}