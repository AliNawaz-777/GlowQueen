<?php

namespace Webkul\Discount\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CatalogRuleProductsProxy extends ModelProxy
{

}
