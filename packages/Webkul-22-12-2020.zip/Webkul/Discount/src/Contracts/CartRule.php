<?php

namespace Webkul\Discount\Contracts;

interface CartRule
{
}