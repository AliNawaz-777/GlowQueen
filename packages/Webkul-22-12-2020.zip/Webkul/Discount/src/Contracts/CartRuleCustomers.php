<?php

namespace Webkul\Discount\Contracts;

interface CartRuleCustomers
{
}