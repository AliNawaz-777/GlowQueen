<?php

namespace Webkul\Discount\Contracts;

interface CartRuleCouponsUsage
{
}