<?php

namespace Webkul\Discount\Contracts;

interface CartRuleLabels
{
}