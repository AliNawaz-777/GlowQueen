<?php

namespace Webkul\Discount\Contracts;

interface CatalogRuleChannels
{
}