<?php

namespace Webkul\Discount\Contracts;

interface CatalogRuleCustomerGroups
{
}