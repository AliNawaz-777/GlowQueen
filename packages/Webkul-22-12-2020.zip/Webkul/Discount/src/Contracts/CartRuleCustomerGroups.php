<?php

namespace Webkul\Discount\Contracts;

interface CartRuleCustomerGroups
{

}
