<div class="pagination">
    {{ $results->links() }}
</div>