<?php

    return [
        'enter-attribute' => 'Enter :attribute',
        'select-attribute' => 'Select :attribute'
    ];