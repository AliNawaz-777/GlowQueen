<?php
return [
    'datagrid' => [
        'actions' => 'الإجراءات',
        'id' => 'أعمدة المؤشر لها قيمة أكبر من الصفر فقط',

        'massaction' => [
            'mass-delete-confirm' => 'تنفيذ إلى حذف منتقى:resource?',
            'mass-update-status' => 'هل تريد حقا تحديث الحالة من منتقى :resource?',
            'delete' => 'هل تريد حقا حذف هذا :resource?',
            'edit' => 'هل تريد حقا تحرير هذا :resource?',
        ],

        'no-records' => 'لا توجد سجلات',
        'filter-fields-missing' => 'بعض الحقل المطلوب هو لاغ ، رجاء تفقد عمود ، حالة و قيمة صحيح',
        'click_on_action' => 'هل تريد حقا أن تؤدي هذا العمل؟',
        'items-per-page' => 'Items Per Page',
    ]
];