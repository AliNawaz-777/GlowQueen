
 ____              _     _
| __ )  __ _  __ _(_)___| |_ ___
|  _ \ / _` |/ _` | / __| __/ _ \
| |_) | (_| | (_| | \__ \ || (_) |
|____/ \__,_|\__, |_|___/\__\___/
             |___/

</>

Welcome to the <info>Bagisto</info> project! Bagisto Community is an <comment>open-source e-commerce ecosystem </comment>
which is built on top of Laravel and Vue.js.

Made with 💖  by the Bagisto Team. Happy helping :)
