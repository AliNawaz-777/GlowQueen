<?php

namespace Webkul\Core\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CurrencyProxy extends ModelProxy
{

}